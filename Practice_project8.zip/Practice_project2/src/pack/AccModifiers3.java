//3. using protected access specifiers

package pack;
public class AccModifiers3 {

	protected void display() 
  { 
      System.out.println("This is protected access specifier"); 
  } 
}
