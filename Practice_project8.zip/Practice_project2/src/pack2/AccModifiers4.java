

//create another package
package pack2;

import pack.*;

public class AccModifiers4 extends AccModifiers3 {

	public static void main(String[] args) {
		AccModifiers4 obj = new AccModifiers4 ();   
	       obj.display();  
	}

}
